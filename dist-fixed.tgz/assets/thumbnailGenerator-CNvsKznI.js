var h=Object.defineProperty;var m=(s,a,e)=>a in s?h(s,a,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[a]=e;var c=(s,a,e)=>m(s,typeof a!="symbol"?a+"":a,e);import{s as u}from"./index-C1BcHSQE.js";class d{constructor(){c(this,"API_BASE","https://api.screenshotone.com/take");c(this,"DEFAULT_OPTIONS",{width:1200,height:630,quality:80,timeout:15e3});c(this,"FALLBACK_IMAGES",{general:"/softwarevala-logo.png",healthcare:"/softwarevala-logo.png",finance:"/softwarevala-logo.png",education:"/softwarevala-logo.png",retail:"/softwarevala-logo.png",food:"/softwarevala-logo.png",transport:"/softwarevala-logo.png",manufacturing:"/softwarevala-logo.png",realestate:"/softwarevala-logo.png",ecommerce:"/softwarevala-logo.png",hospitality:"/softwarevala-logo.png",logistics:"/softwarevala-logo.png",energy:"/softwarevala-logo.png",telecom:"/softwarevala-logo.png",agriculture:"/softwarevala-logo.png",construction:"/softwarevala-logo.png",automotive:"/softwarevala-logo.png",cybersecurity:"/softwarevala-logo.png",media:"/softwarevala-logo.png",social:"/softwarevala-logo.png",analytics:"/softwarevala-logo.png",productivity:"/softwarevala-logo.png","ai-tools":"/softwarevala-logo.png","dev-tools":"/softwarevala-logo.png","cloud-devops":"/softwarevala-logo.png","it-software":"/softwarevala-logo.png","invest-finance":"/softwarevala-logo.png"})}async generateThumbnail(a,e="general",t={}){const o={...this.DEFAULT_OPTIONS,...t};try{const r=await this.generateWithScreenshotOne(a,o);if(r.success)return r;const n=await this.generateWithHtmlToImage(a,o);if(n.success)return n;const l=await this.generateWithFavicon(a);return l.success?l:this.getFallbackThumbnail(e)}catch(r){return console.error("Thumbnail generation failed:",r),this.getFallbackThumbnail(e)}}async generateWithScreenshotOne(a,e){try{const t=new URLSearchParams({access_key:"",url:encodeURIComponent(a),width:e.width.toString(),height:e.height.toString(),device_scale_factor:"2",format:"png",quality:e.quality.toString(),block_ads:"true",block_cookie_banners:"true",block_trackers:"true",delay:"2",element:"body"}),o=await fetch(`${this.API_BASE}?${t}`,{signal:AbortSignal.timeout(e.timeout)});if(!o.ok)throw new Error(`ScreenshotOne API failed: ${o.status}`);const r=await o.blob();return{success:!0,thumbnailUrl:await this.uploadThumbnailToStorage(r,a)}}catch(t){return console.error("ScreenshotOne failed:",t),{success:!1,error:t instanceof Error?t.message:"Unknown error"}}}async generateWithHtmlToImage(a,e){try{const t=`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Preview</title>
            <style>
              body {
                margin: 0;
                padding: 20px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                text-align: center;
              }
              .container {
                max-width: 800px;
                padding: 40px;
                background: rgba(255,255,255,0.1);
                border-radius: 20px;
                backdrop-filter: blur(10px);
              }
              .url {
                font-size: 24px;
                margin-bottom: 20px;
                word-break: break-all;
              }
              .title {
                font-size: 48px;
                font-weight: bold;
                margin-bottom: 20px;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="title">Demo Preview</div>
              <div class="url">${a}</div>
            </div>
          </body>
        </html>
      `,o=new FormData;o.append("html",t),o.append("width",e.width.toString()),o.append("height",e.height.toString()),o.append("quality",e.quality.toString());const r=await fetch("https://hcti.io/v1/image",{method:"POST",headers:{Authorization:"Bearer "},body:o,signal:AbortSignal.timeout(e.timeout)});if(!r.ok)throw new Error(`HTML to Image API failed: ${r.status}`);const n=await r.json(),l=await fetch(n.url).then(g=>g.blob());return{success:!0,thumbnailUrl:await this.uploadThumbnailToStorage(l,a)}}catch(t){return console.error("HTML to Image failed:",t),{success:!1,error:t instanceof Error?t.message:"Unknown error"}}}async generateWithFavicon(a){try{const e=new URL(a).origin,t=[`${e}/favicon.ico`,`${e}/favicon.png`,`${e}/apple-touch-icon.png`,`https://www.google.com/s2/favicons?domain=${e}&sz=256`];for(const o of t)try{if((await fetch(o,{method:"HEAD",signal:AbortSignal.timeout(5e3)})).ok){const n=await fetch(o).then(i=>i.blob());return{success:!0,thumbnailUrl:await this.uploadThumbnailToStorage(n,a)}}}catch{continue}return{success:!1,error:"No favicon found"}}catch(e){return{success:!1,error:e instanceof Error?e.message:"Unknown error"}}}getFallbackThumbnail(a){return{success:!0,thumbnailUrl:this.FALLBACK_IMAGES[a]||this.FALLBACK_IMAGES.general,fallbackUsed:!0}}async uploadThumbnailToStorage(a,e){const t=Date.now(),n=`thumbnails/${`thumbnail-${btoa(e).replace(/[^a-zA-Z0-9]/g,"").substring(0,20)}-${t}.png`}`,{data:l,error:i}=await u.storage.from("thumbnails").upload(n,a,{contentType:"image/png",cacheControl:"31536000"});if(i)throw new Error(`Storage upload failed: ${i.message}`);const{data:{publicUrl:g}}=u.storage.from("thumbnails").getPublicUrl(n);return g}async updateProductThumbnail(a,e){const{error:t}=await u.from("products").update({thumbnail_url:e,updated_at:new Date().toISOString()}).eq("id",a);if(t)throw new Error(`Database update failed: ${t.message}`)}async generateAndUpdateThumbnail(a,e,t="general"){try{const o=await this.generateThumbnail(e,t);return o.success&&o.thumbnailUrl&&await this.updateProductThumbnail(a,o.thumbnailUrl),o}catch(o){return console.error("Failed to generate and update thumbnail:",o),{success:!1,error:o instanceof Error?o.message:"Unknown error"}}}async batchGenerateThumbnails(a){return(await Promise.allSettled(a.map(async t=>({productId:t.id,result:await this.generateAndUpdateThumbnail(t.id,t.demo_url,t.category)})))).map((t,o)=>t.status==="fulfilled"?t.value:{productId:a[o].id,result:{success:!1,error:t.reason instanceof Error?t.reason.message:"Unknown error"}})}}const f=new d;async function w(s,a,e){return a?f.generateAndUpdateThumbnail(s,a,e):{success:!1,error:"No demo URL provided"}}export{w as g};
