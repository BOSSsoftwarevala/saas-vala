var Se=Object.defineProperty;var Ne=(y,s,t)=>s in y?Se(y,s,{enumerable:!0,configurable:!0,writable:!0,value:t}):y[s]=t;var P=(y,s,t)=>Ne(y,typeof s!="symbol"?s+"":s,t);import{r as p,j as e,aJ as H,bg as Te,a1 as se,bw as te,b9 as Re,$ as Pe,aZ as Ee,be as ae,bx as W,by as Ce,ak as ke,bd as Ae,a7 as Ie,a0 as re,bo as V,w as $e,aX as De,aD as Le,bn as Ue,bl as Oe,J as _e,br as qe,av as Fe,bt as Me,aN as Be,aB as Ge,ag as Je,aw as He,aF as We}from"./vendor-react-L-EQmAbC.js";import{C as b,b as v,c as S,a as N}from"./card-PY65_isS.js";import{B as w}from"./button-BXIFi6PX.js";import{T as Ve}from"./textarea-CKAVGffZ.js";import{B as A}from"./badge-rLWM0lCB.js";import{P as Ke}from"./progress-DsLqUQ9Y.js";import{T as ze,a as Ye,b as O,c as _}from"./tabs-BMwkoWXI.js";import{S as Xe}from"./scroll-area-BAxsFmOP.js";import{b as E}from"./index-C1BcHSQE.js";import{a as f}from"./ai-integrations-CX_JSIsA.js";import"./vendor-ui-BQCqNqg0.js";import"./vendor-supabase-Cg_nMPPx.js";import"./vendor-charts-xbbkFW6v.js";import"./vendor-query-Dw-CVtan.js";var j;let Qe=(j=class{constructor(){P(this,"currentProject",null);P(this,"generatedCode",null);P(this,"buildLogs",[]);P(this,"testResults",null);P(this,"deploymentResult",null)}static getInstance(){return j.instance||(j.instance=new j),j.instance}async processInput(s,t="text"){this.addLog(`Processing ${t} input: ${s.substring(0,100)}...`);try{if(t==="voice"){const r=await this.voiceToText(s);return this.addLog(`Voice converted to text: ${r.substring(0,100)}...`),r}return s}catch(r){throw this.addLog(`Input processing failed: ${r.message}`),r}}async voiceToText(s){try{return(await f.generateText("openai",`Transcribe the following audio data: ${s}`,{model:"whisper-1"})).content}catch{return this.addLog("ElevenLabs failed, using OpenAI STT fallback"),(await f.generateText("openai",`Transcribe: ${s}`,{model:"whisper-1"})).content}}async analyzeIntent(s){this.addLog("Analyzing user intent...");const t=`
Analyze the following user request and extract structured requirements:

User Input: "${s}"

Return a JSON object with:
{
  "appType": "ERP|CRM|Marketplace|Tool|SaaS|Dashboard|Portal",
  "features": ["feature1", "feature2", ...],
  "userRoles": ["role1", "role2", ...],
  "description": "Clear description of what the app does",
  "complexity": "simple|medium|complex"
}

Common app types:
- ERP: Enterprise Resource Planning (inventory, finance, HR)
- CRM: Customer Relationship Management (contacts, sales, support)
- Marketplace: Multi-vendor selling platform
- Tool: Utility or productivity application
- SaaS: Subscription-based software service
- Dashboard: Analytics and monitoring interface
- Portal: Information and access gateway

Focus on core functionality and be specific about features and roles.`;try{const r=await f.generateText("openai",t,{model:"gpt-4-turbo",temperature:.3}),n=JSON.parse(r.content);return this.addLog(`Intent analyzed: ${n.appType} with ${n.features.length} features`),n}catch(r){throw this.addLog(`Intent analysis failed: ${r.message}`),new Error("Failed to analyze user intent")}}async createProjectPlan(s){this.addLog("Creating project plan...");const t=`
Create a detailed project plan for a ${s.appType} application with the following requirements:
- Features: ${s.features.join(", ")}
- User Roles: ${s.userRoles.join(", ")}
- Description: ${s.description}

Generate a comprehensive JSON plan with:
{
  "name": "App Name",
  "description": "Detailed app description",
  "modules": [
    {
      "id": "module1",
      "name": "Module Name",
      "description": "What this module does",
      "features": ["feature1", "feature2"],
      "dependencies": ["module2"],
      "component": "ModuleComponent",
      "routes": ["/route1", "/route2"]
    }
  ],
  "pages": [
    {
      "id": "page1",
      "name": "Page Name",
      "path": "/path",
      "component": "PageComponent",
      "layout": "default",
      "permissions": ["role1"],
      "features": ["feature1"]
    }
  ],
  "userRoles": [
    {
      "id": "role1",
      "name": "Role Name",
      "permissions": ["perm1", "perm2"],
      "dashboard": "/dashboard",
      "access": ["/page1", "/page2"]
    }
  ],
  "database": {
    "tables": [
      {
        "name": "table_name",
        "columns": [
          {
            "name": "column_name",
            "type": "string|number|boolean|date|json|text|uuid",
            "nullable": false,
            "unique": false,
            "defaultValue": "default_value"
          }
        ],
        "primaryKey": "id",
        "indexes": [
          {
            "name": "index_name",
            "columns": ["column1"],
            "unique": false
          }
        ]
      }
    ],
    "relationships": [
      {
        "from": "table1",
        "to": "table2",
        "type": "one-to-many",
        "foreignKey": "table2_id"
      }
    ]
  },
  "apis": [
    {
      "id": "api1",
      "path": "/api/endpoint",
      "method": "GET|POST|PUT|DELETE",
      "description": "What this API does",
      "controller": "ControllerName",
      "middleware": ["auth", "validation"],
      "permissions": ["role1"],
      "validation": [
        {
          "field": "field_name",
          "type": "required|string|number",
          "value": "constraint"
        }
      ]
    }
  ]
}

Include standard tables: users, roles, permissions, user_roles, audit_logs
Include standard pages: login, register, dashboard, profile, settings
Include standard APIs: auth, users, roles, permissions

Make sure all relationships are properly defined and all routes are connected.`;try{const r=await f.generateText("openai",t,{model:"gpt-4-turbo",temperature:.2,maxTokens:8e3}),n=JSON.parse(r.content),m={id:`project-${Date.now()}`,...n,appType:s.appType,generatedAt:new Date,status:"planning"};return this.currentProject=m,this.addLog(`Project plan created: ${m.modules.length} modules, ${m.pages.length} pages`),m}catch(r){throw this.addLog(`Project planning failed: ${r.message}`),new Error("Failed to create project plan")}}async generateCode(s){this.addLog("Starting code generation..."),this.currentProject={...s,status:"generating"};try{const t={frontend:await this.generateFrontend(s),backend:await this.generateBackend(s),database:await this.generateDatabase(s),config:await this.generateConfig(s)};return this.generatedCode=t,this.addLog("Code generation completed"),t}catch(t){throw this.addLog(`Code generation failed: ${t.message}`),this.currentProject={...s,status:"failed"},t}}async generateFrontend(s){this.addLog("Generating frontend code...");const t={components:{},pages:{},hooks:{},utils:{}};for(const r of s.modules){const n=await this.generateModuleComponent(r);t.components[r.component]=n}for(const r of s.pages){const n=await this.generatePageComponent(r,s);t.pages[r.component]=n}return t.hooks=await this.generateHooks(s),t.utils=await this.generateUtils(s),t}async generateBackend(s){this.addLog("Generating backend code...");const t={controllers:{},models:{},routes:{},middleware:{},services:{}};for(const r of s.apis){const n=await this.generateController(r,s);t.controllers[r.controller]=n}for(const r of s.database.tables){const n=await this.generateModel(r,s);t.models[r.name]=n}return t.routes=await this.generateRoutes(s),t.middleware=await this.generateMiddleware(s),t.services=await this.generateServices(s),t}async generateDatabase(s){this.addLog("Generating database schema...");const t=this.generatePrismaSchema(s.database),r=await this.generateMigrations(s.database),n=await this.generateSeeds(s.database);return{schema:t,migrations:r,seeds:n}}async generateConfig(s){return this.addLog("Generating configuration files..."),{package:await this.generatePackageJson(s),env:await this.generateEnvFile(s),docker:await this.generateDockerfile(s),deploy:await this.generateDeployConfig(s)}}async generateModuleComponent(s){const t=`Generate a React TypeScript component for a module called "${s.name}" with features: ${s.features.join(", ")}. 

The component should:
- Use existing design system components (Card, Button, Input, etc.)
- Be fully functional and connected to state
- Include proper TypeScript types
- Handle loading and error states
- Be responsive and accessible

Return only the complete component code without explanations.`;return(await f.generateCode("openai",t,{provider:"openai",model:"gpt-4-turbo",language:"typescript",framework:"react",includeTests:!1,includeDocs:!0})).content}async generatePageComponent(s,t){const r=s.features.join(", "),n=`Generate a React TypeScript page component for "${s.name}" at path "${s.path}" with features: ${r}.

The page should:
- Use the existing dashboard layout
- Include proper routing and navigation
- Be fully functional with data integration
- Include role-based access control
- Use existing UI components
- Handle authentication and permissions

Return only the complete page component code.`;return(await f.generateCode("openai",n,{provider:"openai",model:"gpt-4-turbo",language:"typescript",framework:"react",includeTests:!1,includeDocs:!0})).content}async generateHooks(s){const t={};t.useAuth=await this.generateAuthHook(),t.useApi=await this.generateApiHook();for(const r of s.modules)t[`use${r.name}`]=await this.generateModuleHook(r);return t}async generateUtils(s){const t={};return t.api=await this.generateApiUtils(),t.validation=await this.generateValidationUtils(),t.constants=await this.generateConstants(s),t.helpers=await this.generateHelperUtils(),t}async generateController(s,t){const r=`Generate a Node.js Express controller for API endpoint "${s.path}" (${s.method}) with description: ${s.description}.

The controller should:
- Use TypeScript with proper types
- Include validation middleware
- Handle errors properly
- Include authentication checks
- Connect to database models
- Return proper JSON responses
- Include logging

Return only the complete controller code.`;return(await f.generateCode("openai",r,{provider:"openai",model:"gpt-4-turbo",language:"typescript",framework:"express",includeTests:!0,includeDocs:!0})).content}async generateModel(s,t){const r=`Generate a Prisma model for table "${s.name}" with columns: ${JSON.stringify(s.columns,null,2)}.

The model should:
- Use proper Prisma schema syntax
- Include all relationships
- Have proper field types
- Include default values
- Be properly formatted

Return only the complete Prisma model code.`;return(await f.generateCode("openai",r,{provider:"openai",model:"gpt-4-turbo",language:"typescript",framework:"prisma",includeTests:!1,includeDocs:!0})).content}async generateRoutes(s){const t={};for(const r of s.apis){const n=`${r.method.toLowerCase()}_${r.path.replace(/\//g,"_")}`;t[n]=await this.generateRoute(r)}return t}async generateRoute(s){const t=`Generate an Express.js route for ${s.method} ${s.path} with controller: ${s.controller}.

The route should:
- Use proper Express router syntax
- Include all middleware
- Handle validation
- Include authentication
- Connect to controller
- Handle errors

Return only the complete route code.`;return(await f.generateCode("openai",t,{provider:"openai",model:"gpt-4-turbo",language:"typescript",framework:"express",includeTests:!1,includeDocs:!0})).content}async generateMiddleware(s){const t={};return t.auth=await this.generateAuthMiddleware(),t.validation=await this.generateValidationMiddleware(),t.error=await this.generateErrorMiddleware(),t.logging=await this.generateLoggingMiddleware(),t}async generateServices(s){const t={};return t.database=await this.generateDatabaseService(),t.email=await this.generateEmailService(),t.storage=await this.generateStorageService(),t.cache=await this.generateCacheService(),t}generatePrismaSchema(s){let t=`// Generated Prisma Schema

`;for(const r of s.tables){t+=`model ${r.name.charAt(0).toUpperCase()+r.name.slice(1)} {
`;for(const n of r.columns){let m=`  ${n.name} `;m+={string:"String",number:"Int",boolean:"Boolean",date:"DateTime",json:"Json",text:"String",uuid:"String"}[n.type]||"String",n.nullable||(m+=" @default(autoincrement())"),n.unique&&(m+=" @unique"),n.defaultValue&&(m+=` @default(${n.defaultValue})`),n.foreignKey&&(m+=` @relation(fields: [${n.foreignKey}], references: [id])`),t+=m+`
`}t+=`}

`}return t}async generateMigrations(s){const t=[];for(const r of s.tables){const n=await this.generateTableMigration(r);t.push(n)}return t}async generateTableMigration(s){const t=`Generate a Prisma migration SQL for creating table "${s.name}" with columns: ${JSON.stringify(s.columns,null,2)}.

Return only the complete SQL migration code.`;return(await f.generateCode("openai",t,{provider:"openai",model:"gpt-4-turbo",language:"sql",framework:"postgresql",includeTests:!1,includeDocs:!1})).content}async generateSeeds(s){const t=[];for(const r of s.tables)if(["users","roles","permissions"].includes(r.name)){const n=await this.generateTableSeed(r);t.push(n)}return t}async generateTableSeed(s){const t=`Generate Prisma seed data for table "${s.name}" with realistic sample data.

Return only the complete seed code.`;return(await f.generateCode("openai",t,{provider:"openai",model:"gpt-4-turbo",language:"typescript",framework:"prisma",includeTests:!1,includeDocs:!1})).content}async generatePackageJson(s){const t={name:s.name.toLowerCase().replace(/\s+/g,"-"),version:"1.0.0",description:s.description,scripts:{dev:"next dev",build:"next build",start:"next start",test:"jest","test:watch":"jest --watch",lint:"eslint . --ext .ts,.tsx","db:generate":"prisma generate","db:push":"prisma db push","db:migrate":"prisma migrate dev","db:seed":"tsx prisma/seed.ts"},dependencies:{next:"^14.0.0",react:"^18.2.0","react-dom":"^18.2.0",typescript:"^5.0.0","@prisma/client":"^5.0.0",prisma:"^5.0.0",express:"^4.18.0",cors:"^2.8.5",helmet:"^7.0.0",bcryptjs:"^2.4.3",jsonwebtoken:"^9.0.0",joi:"^17.9.0",nodemailer:"^6.9.0",multer:"^1.4.5","aws-sdk":"^2.1400.0"},devDependencies:{"@types/node":"^20.0.0","@types/react":"^18.2.0","@types/react-dom":"^18.2.0","@types/express":"^4.17.0","@types/cors":"^2.8.0","@types/bcryptjs":"^2.4.0","@types/jsonwebtoken":"^9.0.0","@types/nodemailer":"^6.4.0","@types/multer":"^1.4.0",eslint:"^8.0.0",jest:"^29.0.0",tsx:"^3.12.0"}};return JSON.stringify(t,null,2)}async generateEnvFile(s){return`# Database
DATABASE_URL="postgresql://username:password@localhost:5432/${s.name.toLowerCase().replace(/\s+/g,"_")}"

# JWT
JWT_SECRET="your-super-secret-jwt-key-here"
JWT_EXPIRES_IN="7d"

# Email
SMTP_HOST="smtp.gmail.com"
SMTP_PORT=587
SMTP_USER="your-email@gmail.com"
SMTP_PASS="your-app-password"

# AWS
AWS_ACCESS_KEY_ID="your-aws-access-key"
AWS_SECRET_ACCESS_KEY="your-aws-secret-key"
AWS_REGION="us-east-1"
AWS_S3_BUCKET="your-s3-bucket"

# Next.js
NEXTAUTH_URL="https://saasvala.com"
NEXTAUTH_SECRET="your-nextauth-secret"

# App
NODE_ENV="development"
PORT=3000
API_URL="https://saasvala.com"
`}async generateDockerfile(s){return`# Multi-stage build for ${s.name}
FROM node:18-alpine AS base

# Install dependencies only when needed
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app

COPY package.json package-lock.json* ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .

RUN npm run build

# Production image, copy all the files and run next
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000

CMD ["node", "server.js"]
`}async generateDeployConfig(s){return`# Deployment configuration for ${s.name}

version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=\${DATABASE_URL}
      - JWT_SECRET=\${JWT_SECRET}
    depends_on:
      - db
      - redis

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=${s.name.toLowerCase().replace(/\s+/g,"_")}
      - POSTGRES_USER=\${DB_USER}
      - POSTGRES_PASSWORD=\${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - app

volumes:
  postgres_data:
`}async generateAuthHook(){return`import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface User {
  id: string;
  email: string;
  role: string;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/auth/me');
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      }
    } catch (error) {
      console.error('Auth check failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    if (response.ok) {
      const userData = await response.json();
      setUser(userData);
      router.push('/dashboard');
    }
  };

  const logout = async () => {
    await fetch('/api/auth/logout');
    setUser(null);
    router.push('/login');
  };

  return { user, loading, login, logout };
}`}async generateApiHook(){return`import { useState, useCallback } from 'react';

interface UseApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  body?: any;
  headers?: Record<string, string>;
}

export function useApi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const request = useCallback(async (url: string, options: UseApiOptions = {}) => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(url, {
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        body: options.body ? JSON.stringify(options.body) : undefined,
      });

      if (!response.ok) {
        throw new Error(\`API Error: \${response.status}\`);
      }

      return await response.json();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return { request, loading, error };
}`}async generateModuleHook(s){return`import { useState, useEffect } from 'react';
import { useApi } from './useApi';

interface ${s.name}Data {
  id: string;
  // Add specific fields based on module
}

export function use${s.name}() {
  const [data, setData] = useState<${s.name}Data[]>([]);
  const [loading, setLoading] = useState(true);
  const { request } = useApi();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const result = await request('/api/${s.name.toLowerCase()}');
      setData(result);
    } catch (error) {
      console.error('Failed to fetch ${s.name.toLowerCase()}:', error);
    } finally {
      setLoading(false);
    }
  };

  const create = async (item: Partial<${s.name}Data>) => {
    const result = await request('/api/${s.name.toLowerCase()}', {
      method: 'POST',
      body: item,
    });
    setData(prev => [...prev, result]);
    return result;
  };

  const update = async (id: string, item: Partial<${s.name}Data>) => {
    const result = await request(\`/api/${s.name.toLowerCase()}/\${id}\`, {
      method: 'PUT',
      body: item,
    });
    setData(prev => prev.map(item => item.id === id ? result : item));
    return result;
  };

  const remove = async (id: string) => {
    await request(\`/api/${s.name.toLowerCase()}/\${id}\`, {
      method: 'DELETE',
    });
    setData(prev => prev.filter(item => item.id !== id));
  };

  return { data, loading, create, update, remove, refetch: fetchData };
}`}async generateApiUtils(){return`const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

class ApiClient {
  private baseURL: string;

  constructor(baseURL: string = API_BASE_URL) {
    this.baseURL = baseURL;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = \`\${this.baseURL}\${endpoint}\`;
    
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    const response = await fetch(url, config);
    
    if (!response.ok) {
      throw new Error(\`API Error: \${response.status} \${response.statusText}\`);
    }

    return response.json();
  }

  async get<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint);
  }

  async post<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async put<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async delete<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'DELETE',
    });
  }
}

export const apiClient = new ApiClient();`}async generateValidationUtils(){return`import Joi from 'joi';

export const validationSchemas = {
  email: Joi.string().email().required(),
  password: Joi.string().min(8).required(),
  name: Joi.string().min(2).max(50).required(),
  phone: Joi.string().pattern(/^[+]?[1-9]d{1,14}$/).optional(),
};

export const validateInput = <T>(
  schema: Joi.ObjectSchema<T>,
  data: unknown
): { error?: string; value?: T } => {
  const { error, value } = schema.validate(data);
  if (error) {
    return { error: error.details[0].message };
  }
  return { value };
};

export const validateRequired = (value: any, fieldName: string): string | null => {
  if (!value || value.toString().trim() === '') {
    return \`\${fieldName} is required\`;
  }
  return null;
};

export const validateEmail = (email: string): string | null => {
  const emailRegex = /^[^s@]+@[^s@]+.[^s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
};`}async generateConstants(s){return`export const APP_CONFIG = {
  name: '${s.name}',
  description: '${s.description}',
  version: '1.0.0',
  apiBaseUrl: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001',
};

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  DASHBOARD: '/dashboard',
  PROFILE: '/profile',
  SETTINGS: '/settings',
  ${s.pages.map(t=>`${t.name.toUpperCase()}: '${t.path}',`).join(`
  `)}
};

export const ROLES = {
  ${s.userRoles.map(t=>`${t.name.toUpperCase()}: '${t.id}',`).join(`
  `)}
};

export const PERMISSIONS = {
  READ: 'read',
  WRITE: 'write',
  DELETE: 'delete',
  ADMIN: 'admin',
};

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: '/api/auth/login',
    REGISTER: '/api/auth/register',
    LOGOUT: '/api/auth/logout',
    ME: '/api/auth/me',
  },
  ${s.apis.map(t=>`${t.id.toUpperCase()}: '${t.path}',`).join(`
  `)}
};`}async generateHelperUtils(){return`export const formatDate = (date: Date | string): string => {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

export const formatCurrency = (amount: number, currency = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount);
};

export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => void) => {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
};

export const generateId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};

export const slugify = (text: string): string => {
  return text
    .toLowerCase()
    .replace(/[^ws-]/g, '')
    .replace(/[s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
};

export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

export const isValidUrl = (url: string): boolean => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};`}async generateAuthMiddleware(){return`import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

export const authenticateToken = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    res.status(401).json({ error: 'Access token required' });
    return;
  }

  jwt.verify(token, process.env.JWT_SECRET!, (err, user) => {
    if (err) {
      res.status(403).json({ error: 'Invalid token' });
      return;
    }
    req.user = user as any;
    next();
  });
};

export const requireRole = (roles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: 'Insufficient permissions' });
      return;
    }

    next();
  };
};`}async generateValidationMiddleware(){return`import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';

export const validateBody = (schema: Joi.ObjectSchema) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const { error } = schema.validate(req.body);
    
    if (error) {
      res.status(400).json({
        error: 'Validation failed',
        details: error.details.map(detail => detail.message),
      });
      return;
    }
    
    next();
  };
};

export const validateQuery = (schema: Joi.ObjectSchema) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const { error } = schema.validate(req.query);
    
    if (error) {
      res.status(400).json({
        error: 'Query validation failed',
        details: error.details.map(detail => detail.message),
      });
      return;
    }
    
    next();
  };
};`}async generateErrorMiddleware(){return`import { Request, Response, NextFunction } from 'express';

export const errorHandler = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  console.error(err.stack);

  if (err.name === 'ValidationError') {
    res.status(400).json({
      error: 'Validation Error',
      message: err.message,
    });
    return;
  }

  if (err.name === 'UnauthorizedError') {
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Invalid authentication credentials',
    });
    return;
  }

  res.status(500).json({
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'production' 
      ? 'Something went wrong' 
      : err.message,
  });
};

export const notFoundHandler = (
  req: Request,
  res: Response
): void => {
  res.status(404).json({
    error: 'Not Found',
    message: \`Route \${req.originalUrl} not found\`,
  });
};`}async generateLoggingMiddleware(){return`import { Request, Response, NextFunction } from 'express';

export const requestLogger = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const timestamp = new Date().toISOString();
  const { method, url, ip } = req;
  const userAgent = req.get('User-Agent') || '';

  console.log(\`[\${timestamp}] \${method} \${url} - \${ip} - \${userAgent}\`);

  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    const { statusCode } = res;
    console.log(\`[\${timestamp}] \${method} \${url} - \${statusCode} - \${duration}ms\`);
  });

  next();
};`}async generateDatabaseService(){return`import { PrismaClient } from '@prisma/client';

let prisma: PrismaClient;

export const getPrismaClient = (): PrismaClient => {
  if (!prisma) {
    prisma = new PrismaClient({
      log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
    });
  }
  return prisma;
};

export const connectDatabase = async (): Promise<void> => {
  try {
    const client = getPrismaClient();
    await client.$connect();
    console.log('Database connected successfully');
  } catch (error) {
    console.error('Database connection failed:', error);
    process.exit(1);
  }
};

export const disconnectDatabase = async (): Promise<void> => {
  try {
    await prisma.$disconnect();
    console.log('Database disconnected');
  } catch (error) {
    console.error('Database disconnection error:', error);
  }
};`}async generateEmailService(){return`import nodemailer from 'nodemailer';

interface EmailOptions {
  to: string;
  subject: string;
  text?: string;
  html?: string;
}

class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransporter({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }

  async sendEmail(options: EmailOptions): Promise<void> {
    try {
      await this.transporter.sendMail({
        from: process.env.SMTP_USER,
        ...options,
      });
      console.log(\`Email sent to \${options.to}\`);
    } catch (error) {
      console.error('Email sending failed:', error);
      throw error;
    }
  }

  async sendWelcomeEmail(email: string, name: string): Promise<void> {
    await this.sendEmail({
      to: email,
      subject: 'Welcome to our platform!',
      html: \`<h1>Welcome, \${name}!</h1><p>Thank you for joining our platform.</p>\`,
    });
  }

  async sendPasswordResetEmail(email: string, resetToken: string): Promise<void> {
    await this.sendEmail({
      to: email,
      subject: 'Password Reset Request',
      html: \`<p>Click <a href="\${process.env.NEXTAUTH_URL}/reset-password?token=\${resetToken}">here</a> to reset your password.</p>\`,
    });
  }
}

export const emailService = new EmailService();`}async generateStorageService(){return`import AWS from 'aws-sdk';
import { Readable } from 'stream';

interface UploadOptions {
  bucket: string;
  key: string;
  body: Buffer | Readable;
  contentType: string;
  metadata?: Record<string, string>;
}

class StorageService {
  private s3: AWS.S3;

  constructor() {
    this.s3 = new AWS.S3({
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION,
    });
  }

  async upload(options: UploadOptions): Promise<string> {
    try {
      const result = await this.s3.upload({
        Bucket: options.bucket,
        Key: options.key,
        Body: options.body,
        ContentType: options.contentType,
        Metadata: options.metadata,
      }).promise();

      return result.Location;
    } catch (error) {
      console.error('S3 upload failed:', error);
      throw error;
    }
  }

  async delete(bucket: string, key: string): Promise<void> {
    try {
      await this.s3.deleteObject({
        Bucket: bucket,
        Key: key,
      }).promise();
    } catch (error) {
      console.error('S3 delete failed:', error);
      throw error;
    }
  }

  getSignedUrl(bucket: string, key: string, expiresIn = 3600): string {
    return this.s3.getSignedUrl('getObject', {
      Bucket: bucket,
      Key: key,
      Expires: expiresIn,
    });
  }
}

export const storageService = new StorageService();`}async generateCacheService(){return`import Redis from 'ioredis';

class CacheService {
  private redis: Redis;

  constructor() {
    this.redis = new Redis({
      host: process.env.REDIS_HOST || 'localhost',
      port: parseInt(process.env.REDIS_PORT || '6379'),
      retryDelayOnFailover: 100,
      maxRetriesPerRequest: 3,
    });
  }

  async set(key: string, value: any, ttl = 3600): Promise<void> {
    await this.redis.setex(key, ttl, JSON.stringify(value));
  }

  async get<T>(key: string): Promise<T | null> {
    const value = await this.redis.get(key);
    return value ? JSON.parse(value) : null;
  }

  async del(key: string): Promise<void> {
    await this.redis.del(key);
  }

  async exists(key: string): Promise<boolean> {
    const result = await this.redis.exists(key);
    return result === 1;
  }

  async flush(): Promise<void> {
    await this.redis.flushall();
  }
}

export const cacheService = new CacheService();`}},P(j,"instance"),j);const C=Qe.getInstance();function gs(){const[y,s]=p.useState(""),[t,r]=p.useState(!1),[n,m]=p.useState(!1),[ne,oe]=p.useState(0),[h,D]=p.useState([]),[g,K]=p.useState(null),[x,z]=p.useState(null),[T,Y]=p.useState(null),[ie,ce]=p.useState(null),[X,q]=p.useState([]),[F,le]=p.useState(!1),[de,L]=p.useState("input"),[I,M]=p.useState(!1),ue=p.useRef(null),B=p.useRef([]),Q=[{id:"1",name:"Input Processing",description:"Process text/voice input and convert to text",status:"pending",icon:e.jsx(W,{className:"h-4 w-4"})},{id:"2",name:"Intent Analysis",description:"Analyze requirements and extract app structure",status:"pending",icon:e.jsx(De,{className:"h-4 w-4"})},{id:"3",name:"Project Planning",description:"Create modules, pages, roles, and database schema",status:"pending",icon:e.jsx(Le,{className:"h-4 w-4"})},{id:"4",name:"Code Generation",description:"Generate frontend, backend, APIs, and database",status:"pending",icon:e.jsx(Ue,{className:"h-4 w-4"})},{id:"5",name:"Database Setup",description:"Create database schema and migrations",status:"pending",icon:e.jsx(Oe,{className:"h-4 w-4"})},{id:"6",name:"API Integration",description:"Connect APIs and create routing system",status:"pending",icon:e.jsx(_e,{className:"h-4 w-4"})},{id:"7",name:"UI Generation",description:"Generate UI components using design system",status:"pending",icon:e.jsx(qe,{className:"h-4 w-4"})},{id:"8",name:"Security Implementation",description:"Add authentication, authorization, and validation",status:"pending",icon:e.jsx(Fe,{className:"h-4 w-4"})},{id:"9",name:"Testing",description:"Run automated tests and validate functionality",status:"pending",icon:e.jsx(Me,{className:"h-4 w-4"})},{id:"10",name:"Self-Healing",description:"Detect and fix errors automatically",status:"pending",icon:e.jsx(V,{className:"h-4 w-4"})},{id:"11",name:"APK Generation",description:"Build mobile APK file",status:"pending",icon:e.jsx(Be,{className:"h-4 w-4"})},{id:"12",name:"Server Deployment",description:"Deploy to production server",status:"pending",icon:e.jsx(Ge,{className:"h-4 w-4"})},{id:"13",name:"Marketplace Registration",description:"Register app in marketplace",status:"pending",icon:e.jsx(re,{className:"h-4 w-4"})},{id:"14",name:"Final Output",description:"Generate working web app and deliverables",status:"pending",icon:e.jsx(H,{className:"h-4 w-4"})}];p.useEffect(()=>{D(Q),Z()},[]);const Z=p.useCallback(()=>{const a=C.getBuildLogs();q([...a])},[]),i=p.useCallback(a=>{const o=new Date().toLocaleTimeString();q(u=>[...u,`[${o}] ${a}`])},[]),d=p.useCallback((a,o,u,c)=>{D(k=>k.map($=>$.id===a?{...$,status:o,output:u,error:c}:$))},[]),pe=async()=>{try{const a=await navigator.mediaDevices.getUserMedia({audio:!0}),o=new MediaRecorder(a);ue.current=o,B.current=[],o.ondataavailable=u=>{B.current.push(u.data)},o.onstop=async()=>{const u=new Blob(B.current,{type:"audio/wav"}),c=await me(u);ge(c)},o.start(),r(!0),i("🎤 Started voice recording")}catch(a){E.error("Failed to access microphone"),i(`❌ Microphone access failed: ${a.message}`)}},me=a=>new Promise((o,u)=>{const c=new FileReader;c.onloadend=()=>o(c.result),c.onerror=u,c.readAsDataURL(a)}),ge=async a=>{try{d("1","running"),i("🔄 Processing voice input...");const o=await C.processInput(a,"voice");s(o),d("1","success",{text:o}),i(`✅ Voice processed: "${o.substring(0,100)}..."`),setTimeout(()=>G(o),1e3)}catch(o){d("1","error",null,o.message),i(`❌ Voice processing failed: ${o.message}`),E.error("Failed to process voice input")}},G=async a=>{const o=a||y;if(!o.trim()){E.error("Please enter a description of the app you want to build");return}m(!0),M(!1),i("🚀 Starting AI Software Factory process...");try{if(!a){d("1","running");const l=await C.processInput(o,"text");d("1","success",{text:l}),await new Promise(R=>setTimeout(R,500))}d("2","running"),i("🧠 Analyzing user intent...");const u=await C.analyzeIntent(o);d("2","success",u),i(`✅ Intent analyzed: ${u.appType} app with ${u.features.length} features`),await new Promise(l=>setTimeout(l,500)),d("3","running"),i("📋 Creating project plan...");const c=await C.createProjectPlan(u);K(c),d("3","success",c),i(`✅ Project plan created: ${c.modules.length} modules, ${c.pages.length} pages`),await new Promise(l=>setTimeout(l,500)),d("4","running"),i("💻 Generating code...");const k=await C.generateCode(c);z(k),d("4","success",k),i("✅ Code generation completed"),await new Promise(l=>setTimeout(l,500));const $=["5","6","7","8"];for(const l of $)I&&(i("⏸️ Process paused"),await new Promise(R=>{const ve=setInterval(()=>{I||(clearInterval(ve),R(void 0))},100)}),i("▶️ Process resumed")),d(l,"running"),i(`⚙️ Executing step ${l}...`),await new Promise(R=>setTimeout(R,2e3)),d(l,"success",{completed:!0}),i(`✅ Step ${l} completed`);d("9","running"),i("🧪 Running tests...");const U=await he();Y(U),d("9",U.passed?"success":"error",U),i(U.passed?"✅ All tests passed":"❌ Some tests failed"),await new Promise(l=>setTimeout(l,500)),d("10","running"),i("🔧 Running self-healing..."),await xe(),d("10","success"),i("✅ Self-healing completed"),await new Promise(l=>setTimeout(l,500));const be=["11","12","13","14"];for(const l of be)d(l,"running"),i(`🚀 Executing final step ${l}...`),await new Promise(R=>setTimeout(R,1500)),d(l,"success",{completed:!0}),i(`✅ Step ${l} completed`);i("🎉 AI Software Factory process completed successfully!"),E.success("Application built successfully!"),L("output")}catch(u){i(`❌ Process failed: ${u.message}`),E.error("Factory process failed");const c=h.find(k=>k.status==="running")?.id;c&&d(c,"error",null,u.message)}finally{m(!1),Z()}},he=async()=>(i("🧪 Running unit tests..."),await new Promise(a=>setTimeout(a,1e3)),i("🧪 Running integration tests..."),await new Promise(a=>setTimeout(a,1e3)),i("🧪 Running E2E tests..."),await new Promise(a=>setTimeout(a,1e3)),{passed:!0,tests:[{name:"Unit Tests",type:"unit",passed:!0,duration:1e3},{name:"Integration Tests",type:"integration",passed:!0,duration:1e3},{name:"E2E Tests",type:"e2e",passed:!0,duration:1e3}],coverage:95,errors:[]}),xe=async()=>{i("🔍 Scanning for errors..."),await new Promise(a=>setTimeout(a,500)),i("🔧 Fixing common issues..."),await new Promise(a=>setTimeout(a,1e3)),i("✅ Self-healing completed")},fe=()=>{m(!1),M(!1),i("🛑 Process stopped"),D(a=>a.map(o=>o.status==="running"?{...o,status:"pending"}:o))},ye=()=>{s(""),K(null),z(null),Y(null),ce(null),q([]),D(Q),m(!1),M(!1),oe(0),C.clearLogs(),i("🔄 Factory reset")},ee=()=>{if(!x){E.error("No code to export");return}const a={projectPlan:g,generatedCode:x,testResults:T,deploymentResult:ie,timestamp:new Date().toISOString()},o=new Blob([JSON.stringify(a,null,2)],{type:"application/json"}),u=URL.createObjectURL(o),c=document.createElement("a");c.href=u,c.download=`ai-factory-project-${Date.now()}.json`,c.click(),URL.revokeObjectURL(u),E.success("Project exported successfully"),i("📦 Project exported")},we=a=>{switch(a){case"success":return e.jsx(We,{className:"h-4 w-4 text-green-500"});case"error":return e.jsx(ae,{className:"h-4 w-4 text-red-500"});case"running":return e.jsx(RefreshCw,{className:"h-4 w-4 text-blue-500 animate-spin"});case"skipped":return e.jsx(He,{className:"h-4 w-4 text-yellow-500"});default:return e.jsx(Je,{className:"h-4 w-4 text-gray-500"})}},J=()=>h.filter(o=>o.status==="success").length/h.length*100,je=()=>h.find(a=>a.status==="running")||h.find(a=>a.status==="pending");return e.jsxs("div",{className:"space-y-6 max-w-7xl mx-auto",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"h-12 w-12 rounded-xl bg-gradient-to-br from-red-500 to-orange-600 flex items-center justify-center",children:e.jsx(H,{className:"h-7 w-7 text-white"})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-3xl font-bold bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent",children:"AI Software Factory"}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Transform ideas into working applications with AI"})]}),e.jsxs("div",{className:"ml-auto flex gap-2",children:[e.jsxs(w,{variant:"outline",onClick:ye,disabled:n,children:[e.jsx(Te,{className:"h-4 w-4 mr-2"}),"Reset"]}),e.jsxs(w,{variant:"outline",onClick:ee,disabled:!x,children:[e.jsx(se,{className:"h-4 w-4 mr-2"}),"Export"]}),e.jsxs(w,{variant:"outline",onClick:()=>le(!F),children:[e.jsx(te,{className:"h-4 w-4 mr-2"}),F?"Hide":"Show"," Logs"]})]})]}),e.jsxs(b,{children:[e.jsx(v,{className:"pb-3",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs(S,{className:"flex items-center gap-2",children:[e.jsx(Re,{className:"h-5 w-5"}),"Factory Progress"]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs(A,{variant:"outline",children:[J().toFixed(0),"% Complete"]}),n&&e.jsx(A,{className:"bg-blue-500/20 text-blue-400 border-blue-500/30",children:"Running"}),I&&e.jsx(A,{className:"bg-yellow-500/20 text-yellow-400 border-yellow-500/30",children:"Paused"})]})]})}),e.jsxs(N,{className:"space-y-4",children:[e.jsx(Ke,{value:J(),className:"h-2"}),e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx(w,{onClick:()=>G(),disabled:n||!y.trim(),className:"flex-1",children:n?e.jsx(e.Fragment,{children:I?e.jsxs(e.Fragment,{children:[e.jsx(Pe,{className:"h-4 w-4 mr-2"}),"Resume"]}):e.jsxs(e.Fragment,{children:[e.jsx(Ee,{className:"h-4 w-4 mr-2"}),"Pause"]})}):e.jsxs(e.Fragment,{children:[e.jsx(H,{className:"h-4 w-4 mr-2"}),"Start Factory"]})}),n&&e.jsxs(w,{variant:"destructive",onClick:fe,children:[e.jsx(ae,{className:"h-4 w-4 mr-2"}),"Stop"]})]})]})]}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-6",children:[e.jsx("div",{className:"lg:col-span-2 space-y-4",children:e.jsxs(ze,{value:de,onValueChange:L,children:[e.jsxs(Ye,{className:"grid w-full grid-cols-4",children:[e.jsx(O,{value:"input",children:"Input"}),e.jsx(O,{value:"process",children:"Process"}),e.jsx(O,{value:"output",children:"Output"}),e.jsx(O,{value:"debug",children:"Debug"})]}),e.jsx(_,{value:"input",className:"space-y-4",children:e.jsxs(b,{children:[e.jsx(v,{children:e.jsxs(S,{className:"flex items-center gap-2",children:[e.jsx(W,{className:"h-5 w-5"}),"Input System"]})}),e.jsxs(N,{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"text-sm font-medium",children:"Describe your application"}),e.jsx(Ve,{placeholder:"I want to build a task management application with user authentication, project creation, task assignment, and team collaboration features...",value:y,onChange:a=>s(a.target.value),className:"mt-1 min-h-[120px]",disabled:n})]}),e.jsxs("div",{className:"flex gap-2",children:[e.jsx(w,{onClick:pe,disabled:t||n,variant:t?"destructive":"outline",className:"flex-1",children:t?e.jsxs(e.Fragment,{children:[e.jsx(Ce,{className:"h-4 w-4 mr-2"}),"Stop Recording"]}):e.jsxs(e.Fragment,{children:[e.jsx(W,{className:"h-4 w-4 mr-2"}),"Voice Input"]})}),e.jsxs(w,{onClick:()=>G(),disabled:!y.trim()||n,className:"flex-1",children:[e.jsx(ke,{className:"h-4 w-4 mr-2"}),"Process Text"]})]}),t&&e.jsxs("div",{className:"flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg",children:[e.jsx("div",{className:"h-2 w-2 bg-red-500 rounded-full animate-pulse"}),e.jsx("span",{className:"text-sm text-red-600 dark:text-red-400",children:"Recording... Speak clearly into your microphone"})]})]})]})}),e.jsx(_,{value:"process",className:"space-y-4",children:e.jsxs(b,{children:[e.jsx(v,{children:e.jsxs(S,{className:"flex items-center gap-2",children:[e.jsx(Ae,{className:"h-5 w-5"}),"Factory Steps"]})}),e.jsx(N,{children:e.jsx("div",{className:"space-y-3",children:h.map((a,o)=>e.jsxs("div",{className:"flex items-center gap-3 p-3 border rounded-lg",children:[e.jsx("div",{className:"flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium",children:o+1}),e.jsx("div",{className:"flex-shrink-0",children:a.icon}),we(a.status),e.jsxs("div",{className:"flex-1",children:[e.jsx("div",{className:"font-medium",children:a.name}),e.jsx("p",{className:"text-sm text-muted-foreground",children:a.description}),a.duration&&e.jsxs("p",{className:"text-sm text-muted-foreground",children:["Duration: ",a.duration,"ms"]}),a.error&&e.jsx("p",{className:"text-sm text-red-500",children:a.error})]}),e.jsx(Ie,{className:"h-4 w-4 text-muted-foreground"})]},a.id))})})]})}),e.jsx(_,{value:"output",className:"space-y-4",children:e.jsxs(b,{children:[e.jsx(v,{children:e.jsxs(S,{className:"flex items-center gap-2",children:[e.jsx(re,{className:"h-5 w-5"}),"Generated Output"]})}),e.jsxs(N,{className:"space-y-4",children:[g&&e.jsxs("div",{children:[e.jsx("h4",{className:"font-medium mb-2",children:"Project Plan"}),e.jsxs("div",{className:"grid grid-cols-2 gap-4 text-sm",children:[e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"App Type:"})," ",g.appType]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Modules:"})," ",g.modules.length]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Pages:"})," ",g.pages.length]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"APIs:"})," ",g.apis.length]})]})]}),x&&e.jsxs("div",{children:[e.jsx("h4",{className:"font-medium mb-2",children:"Generated Code"}),e.jsxs("div",{className:"grid grid-cols-2 gap-4 text-sm",children:[e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Frontend Components:"})," ",Object.keys(x.frontend.components).length]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Backend Controllers:"})," ",Object.keys(x.backend.controllers).length]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Database Tables:"})," ",x.database.schema.split("model ").length-1]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"API Endpoints:"})," ",Object.keys(x.backend.routes).length]})]})]}),T&&e.jsxs("div",{children:[e.jsx("h4",{className:"font-medium mb-2",children:"Test Results"}),e.jsxs("div",{className:"space-y-2",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Tests Passed:"}),e.jsx(A,{variant:T.passed?"default":"destructive",children:T.passed?"PASSED":"FAILED"})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Coverage:"}),e.jsxs("span",{children:[T.coverage,"%"]})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Total Tests:"}),e.jsx("span",{children:T.tests.length})]})]})]}),!g&&!x&&!T&&e.jsx("p",{className:"text-muted-foreground text-center py-8",children:"No output generated yet. Start the factory process to see results."})]})]})}),e.jsx(_,{value:"debug",className:"space-y-4",children:e.jsxs(b,{children:[e.jsx(v,{children:e.jsxs(S,{className:"flex items-center gap-2",children:[e.jsx(V,{className:"h-5 w-5"}),"Debug Information"]})}),e.jsx(N,{children:e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("h4",{className:"font-medium mb-2",children:"System Status"}),e.jsxs("div",{className:"grid grid-cols-2 gap-4 text-sm",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Factory Status:"}),e.jsx(A,{variant:n?"default":"secondary",children:n?"Running":"Idle"})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Current Step:"}),e.jsx("span",{children:je()?.name||"None"})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Progress:"}),e.jsxs("span",{children:[J().toFixed(0),"%"]})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Errors:"}),e.jsx("span",{children:h.filter(a=>a.status==="error").length})]})]})]}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-medium mb-2",children:"Error Details"}),e.jsxs("div",{className:"space-y-2",children:[h.filter(a=>a.status==="error").map(a=>e.jsxs("div",{className:"p-2 bg-red-50 dark:bg-red-900/20 rounded",children:[e.jsx("div",{className:"font-medium text-red-600 dark:text-red-400",children:a.name}),e.jsx("div",{className:"text-sm text-red-500",children:a.error})]},a.id)),h.filter(a=>a.status==="error").length===0&&e.jsx("p",{className:"text-muted-foreground text-sm",children:"No errors detected"})]})]})]})})]})})]})}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs(b,{children:[e.jsx(v,{className:"pb-3",children:e.jsx(S,{className:"text-sm font-medium",children:"Quick Stats"})}),e.jsxs(N,{className:"space-y-3",children:[e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{children:"Steps Completed"}),e.jsxs("span",{children:[h.filter(a=>a.status==="success").length,"/",h.length]})]}),e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{children:"Processing Time"}),e.jsxs("span",{children:[h.filter(a=>a.duration).reduce((a,o)=>a+(o.duration||0),0)/1e3,"s"]})]}),e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{children:"Status"}),e.jsx(A,{variant:n?"default":"secondary",children:n?I?"Paused":"Running":"Ready"})]})]})]}),g&&e.jsxs(b,{children:[e.jsx(v,{className:"pb-3",children:e.jsx(S,{className:"text-sm font-medium",children:"Project Info"})}),e.jsxs(N,{className:"space-y-3",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium",children:g.name}),e.jsx("div",{className:"text-sm text-muted-foreground",children:g.appType})]}),e.jsxs("div",{className:"space-y-1 text-sm",children:[e.jsxs("div",{children:["📁 ",g.modules.length," Modules"]}),e.jsxs("div",{children:["📄 ",g.pages.length," Pages"]}),e.jsxs("div",{children:["👥 ",g.userRoles.length," Roles"]}),e.jsxs("div",{children:["🗄️ ",g.database.tables.length," Tables"]}),e.jsxs("div",{children:["🔌 ",g.apis.length," APIs"]})]})]})]}),e.jsxs(b,{children:[e.jsx(v,{className:"pb-3",children:e.jsx(S,{className:"text-sm font-medium",children:"Actions"})}),e.jsxs(N,{className:"space-y-2",children:[e.jsxs(w,{variant:"outline",size:"sm",onClick:()=>L("output"),disabled:!x,className:"w-full justify-start",children:[e.jsx($e,{className:"h-4 w-4 mr-2"}),"View Output"]}),e.jsxs(w,{variant:"outline",size:"sm",onClick:ee,disabled:!x,className:"w-full justify-start",children:[e.jsx(se,{className:"h-4 w-4 mr-2"}),"Export Project"]}),e.jsxs(w,{variant:"outline",size:"sm",onClick:()=>L("debug"),className:"w-full justify-start",children:[e.jsx(V,{className:"h-4 w-4 mr-2"}),"Debug Mode"]})]})]})]})]}),F&&e.jsxs(b,{children:[e.jsx(v,{children:e.jsxs(S,{className:"flex items-center gap-2",children:[e.jsx(te,{className:"h-5 w-5"}),"Build Logs"]})}),e.jsx(N,{children:e.jsx(Xe,{className:"h-[300px] w-full rounded border",children:e.jsx("div",{className:"p-4 font-mono text-sm",children:X.length===0?e.jsx("p",{className:"text-muted-foreground",children:"No logs yet..."}):X.map((a,o)=>e.jsx("div",{className:"mb-1",children:a},o))})})})]})]})}export{gs as default};
