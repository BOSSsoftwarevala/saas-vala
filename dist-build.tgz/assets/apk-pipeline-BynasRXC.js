var w=Object.defineProperty;var v=(d,e,t)=>e in d?w(d,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):d[e]=t;var u=(d,e,t)=>v(d,typeof e!="symbol"?e+"":e,t);const p=()=>{throw new Error("execSync not available in browser")},c={promises:{readFile:async()=>"",writeFile:async()=>{},mkdir:async()=>{},access:async()=>{},stat:async()=>({isFile:()=>!1,isDirectory:()=>!1}),readdir:async()=>[],rm:async()=>{},copyFile:async()=>{}}},o={join:(...d)=>d.join("/"),resolve:(...d)=>d.join("/"),dirname:d=>d.split("/").slice(0,-1).join("/"),basename:d=>d.split("/").pop()||"",extname:d=>d.includes(".")?"."+d.split(".").pop():""},m={createHash:d=>({update:e=>({digest:t=>"mock-hash-"+d+"-"+e.length})}),randomBytes:d=>Buffer.alloc(d).fill(0),createHmac:()=>({update:()=>({digest:()=>"mock-hmac"})})},x=m.createHash,h=class h{constructor(){u(this,"activeBuilds",new Map);u(this,"buildQueue",[]);u(this,"projectInfo",new Map);u(this,"apkStorage",new Map);u(this,"licenseKeys",new Map);u(this,"testResults",new Map);u(this,"buildHistory",[]);u(this,"BUILD_DIR","/tmp/apk-builds");u(this,"OUTPUT_DIR","/tmp/apk-output");u(this,"MAX_CONCURRENT_BUILDS",3);u(this,"BUILD_TIMEOUT",3e5);this.initializeDirectories(),this.startQueueProcessor()}static getInstance(){return h.instance||(h.instance=new h),h.instance}async initializeDirectories(){try{await c.mkdir(this.BUILD_DIR,{recursive:!0}),await c.mkdir(this.OUTPUT_DIR,{recursive:!0})}catch(e){console.error("Failed to initialize directories:",e)}}async submitBuild(e){const t=`build-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,i={id:t,sourceId:e.id,status:"pending",logs:[],errors:[],startTime:new Date};this.activeBuilds.set(t,i);const s={id:`queue-${Date.now()}`,buildId:t,priority:"normal",status:"queued",queuedAt:new Date,retryCount:0,maxRetries:3};return this.buildQueue.push(s),this.buildQueue.sort((a,r)=>{const n={high:3,normal:2,low:1};return n[r.priority]-n[a.priority]}),this.addLog(t,"info","Build submitted to queue","input"),t}async scanRepository(e,t){this.addLog(e,"info","Starting repository scan","scan");const i=o.join(this.BUILD_DIR,e);try{t.type==="github"&&t.url?await this.cloneRepository(t.url,i):t.type==="upload"&&t.zipPath&&await this.extractZip(t.zipPath,i);const s=await this.detectProjectType(i);this.projectInfo.set(e,s);const a=await this.checkMissingFiles(i,s);return s.missingFiles=a,this.addLog(e,"info",`Detected project type: ${s.type}`,"scan"),this.addLog(e,"info",`Missing files: ${a.length}`,"scan"),s}catch(s){throw this.addLog(e,"error",`Repository scan failed: ${s.message}`,"scan"),s}}async cloneRepository(e,t){e.includes("github.com")||`${e}`,p()}async extractZip(e,t){p()}async detectProjectType(e){const t=o.join(e,"package.json"),i=o.join(e,"composer.json"),s=o.join(e,"index.html");let a="static",r="",n="",l="dist";if(await this.fileExists(t)){const f=JSON.parse(await c.readFile(t,"utf-8")),g={...f.dependencies,...f.devDependencies};g.next?(a="next",r="Next.js",n="npm run build",l="out"):g.react?(a="react",r="React",n="npm run build",l="build"):g.vue?(a="vue",r="Vue.js",n="npm run build",l="dist"):g["@angular/core"]?(a="angular",r="Angular",n="npm run build",l="dist"):(a="node",r="Node.js",n="npm run build",l="dist")}else await this.fileExists(i)?(a="php",r="PHP",n="composer install && npm run build",l="dist"):await this.fileExists(s)&&(a="static",r="Static HTML",n="",l=".");return{type:a,framework:r,buildCommand:n,outputDir:l,hasPackageJson:await this.fileExists(t),hasBuildConfig:await this.hasBuildConfig(e),missingFiles:[],dependencies:await this.getDependencies(e)}}async checkMissingFiles(e,t){const i=[],s=["index.html"];t.hasPackageJson&&s.push("package.json");for(const a of s)await this.fileExists(o.join(e,a))||i.push(a);return i}async autoFixProject(e,t,i){this.addLog(e,"info","Starting auto-fix process","fix");try{await this.addMissingFiles(t,i),await this.addAndroidWrapper(t,i),await this.fixDependencies(t,i),await this.generateAndroidConfig(t,i),this.addLog(e,"info","Auto-fix completed successfully","fix")}catch(s){throw this.addLog(e,"error",`Auto-fix failed: ${s.message}`,"fix"),s}}async addMissingFiles(e,t){t.missingFiles.includes("index.html")&&await c.writeFile(o.join(e,"index.html"),`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile App</title>
</head>
<body>
    <div id="app">
        <h1>Welcome to Mobile App</h1>
        <p>Your application is loading...</p>
    </div>
    <script src="app.js"><\/script>
</body>
</html>`)}async addAndroidWrapper(e,t){const i={appId:"com.example.app",appName:"Mobile App",webDir:t.outputDir,server:{androidScheme:"https"}};if(await c.writeFile(o.join(e,"capacitor.config.ts"),`export default ${JSON.stringify(i,null,2)};`),t.hasPackageJson){const s=o.join(e,"package.json"),a=JSON.parse(await c.readFile(s,"utf-8"));a.devDependencies={...a.devDependencies,"@capacitor/android":"^5.0.0","@capacitor/cli":"^5.0.0","@capacitor/core":"^5.0.0"},await c.writeFile(s,JSON.stringify(a,null,2))}}async fixDependencies(e,t){t.hasPackageJson&&p()}async generateAndroidConfig(e,t){const i=`<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/AppTheme">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,s=o.join(e,"android");await c.mkdir(s,{recursive:!0}),await c.writeFile(o.join(s,"AndroidManifest.xml"),i)}async buildAPK(e){this.addLog(e,"info","Starting APK build process","build");const t=this.activeBuilds.get(e);if(!t)throw new Error("Build not found");const i=o.join(this.BUILD_DIR,e),s=this.projectInfo.get(e);if(!s)throw new Error("Project info not found");try{s.buildCommand&&(this.addLog(e,"info",`Running build command: ${s.buildCommand}`,"build"),p(s.buildCommand,{cwd:i,stdio:"pipe"})),p("npx cap init",{cwd:i,stdio:"pipe"}),p("npx cap add android",{cwd:i,stdio:"pipe"}),p("npx cap sync android",{cwd:i,stdio:"pipe"});const a=o.join(i,"android");p("./gradlew assembleRelease",{cwd:a,stdio:"pipe"});const r=o.join(a,"app/build/outputs/apk/release/app-release.apk");if(!await this.fileExists(r))throw new Error("APK not found after build");const n=o.join(this.OUTPUT_DIR,`${e}.apk`);await c.copyFile(r,n);const l=await c.stat(n);return t.status="testing",t.apkPath=n,t.apkSize=l.size,this.addLog(e,"info",`APK built successfully: ${l.size} bytes`,"build"),n}catch(a){throw t.status="failed",t.errors.push(a.message),this.addLog(e,"error",`Build failed: ${a.message}`,"build"),a}}async secureAPK(e,t){this.addLog(e,"info","Applying security measures","security");try{const i=o.join(this.BUILD_DIR,e,"android"),s=o.join(i,"app/build.gradle");if(await this.fileExists(s)){let n=await c.readFile(s,"utf-8");n=n.replace("debuggable true","debuggable false"),n=n.replace("minifyEnabled false","minifyEnabled true"),await c.writeFile(s,n)}const a=o.join(i,"app/proguard-rules.pro");await c.writeFile(a,`
# Add project specific ProGuard rules here.
-keep class com.example.app.** { *; }
-keep class android.webkit.** { *; }
-keep class com.getcapacitor.** { *; }
`),this.addLog(e,"info","Security measures applied","security")}catch(i){throw this.addLog(e,"error",`Security failed: ${i.message}`,"security"),i}}async integrateKeySystem(e,t){this.addLog(e,"info","Integrating key system","keys");try{const i=o.join(this.BUILD_DIR,e),s=o.join(i,this.projectInfo.get(e).outputDir),a=`
// License Validation System
class LicenseValidator {
  constructor() {
    this.apiUrl = 'https://api.vala-builder.com/license/validate';
    this.productId = '${this.projectInfo.get(e)?.type||"default"}';
  }
  
  async validateLicense(key) {
    try {
      const deviceId = await this.getDeviceId();
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          key,
          productId: this.productId,
          deviceId,
        }),
      });
      
      const result = await response.json();
      if (result.valid) {
        localStorage.setItem('license', JSON.stringify(result));
        return true;
      } else {
        this.showInvalidLicense();
        return false;
      }
    } catch (error) {
      console.error('License validation failed:', error);
      this.showInvalidLicense();
      return false;
    }
  }
  
  async getDeviceId() {
    let deviceId = localStorage.getItem('deviceId');
    if (!deviceId) {
      deviceId = 'device-' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('deviceId', deviceId);
    }
    return deviceId;
  }
  
  showInvalidLicense() {
    document.body.innerHTML = \`
      <div style="display: flex; justify-content: center; align-items: center; height: 100vh; font-family: Arial, sans-serif;">
        <div style="text-align: center; padding: 20px; border: 1px solid #ccc; border-radius: 8px;">
          <h2>License Required</h2>
          <p>Please enter your license key to continue:</p>
          <input type="text" id="licenseKey" placeholder="Enter license key" style="padding: 8px; margin: 10px;">
          <br>
          <button onclick="validateAndContinue()" style="padding: 8px 16px; background: #007bff; color: white; border: none; border-radius: 4px;">Validate</button>
        </div>
      </div>
    \`;
    
    window.validateAndContinue = async () => {
      const key = document.getElementById('licenseKey').value;
      const valid = await this.validateLicense(key);
      if (valid) {
        location.reload();
      }
    };
  }
  
  async checkLicense() {
    const license = localStorage.getItem('license');
    if (license) {
      const parsed = JSON.parse(license);
      if (new Date(parsed.expiry) > new Date()) {
        return true;
      }
    }
    
    this.showInvalidLicense();
    return false;
  }
}

// Initialize license validator
const licenseValidator = new LicenseValidator();

// Check license on app start
document.addEventListener('DOMContentLoaded', async () => {
  await licenseValidator.checkLicense();
});
`;await c.writeFile(o.join(s,"license-validator.js"),a);const r=o.join(s,"index.html");if(await this.fileExists(r)){let n=await c.readFile(r,"utf-8");n=n.replace("</body>",'<script src="license-validator.js"><\/script></body>'),await c.writeFile(r,n)}this.addLog(e,"info","Key system integrated","keys")}catch(i){throw this.addLog(e,"error",`Key system integration failed: ${i.message}`,"keys"),i}}async generateLicenseKey(e,t,i=365){const s=`VALA-${m.randomBytes(16).toString("hex").toUpperCase()}`,a={id:`license-${Date.now()}`,productId:e,deviceId:t,key:s,expiry:new Date(Date.now()+i*24*60*60*1e3),active:!0,createdAt:new Date};return this.licenseKeys.set(s,a),s}async validateLicenseKey(e,t){const i=this.licenseKeys.get(e);return!i||!i.active||i.deviceId!==t||new Date>i.expiry?!1:(i.lastUsed=new Date,!0)}async testAPK(e,t){this.addLog(e,"info","Starting APK testing","test");const i={id:`test-${Date.now()}`,buildId:e,status:"running",tests:{launch:!1,uiLoad:!1,keyActivation:!1,functionality:!1},emulatorId:`emu-${Date.now()}`,screenshots:[],logs:[],errors:[]};this.testResults.set(i.id,i);try{await this.installInEmulator(t,i.emulatorId),i.tests.launch=!0,await this.testUILaunch(i.emulatorId,i),await this.testKeyActivation(i.emulatorId,i),await this.testFunctionality(i.emulatorId,i),i.status="passed",this.addLog(e,"info","APK tests passed","test")}catch(s){i.status="failed",i.errors.push(s.message),this.addLog(e,"error",`APK tests failed: ${s.message}`,"test")}return i}async installInEmulator(e,t){p()}async testUILaunch(e,t){p(),await new Promise(i=>setTimeout(i,3e3)),t.tests.uiLoad=!0}async testKeyActivation(e,t){const i=await this.generateLicenseKey("test",e),s=await this.validateLicenseKey(i,e);t.tests.keyActivation=s}async testFunctionality(e,t){t.tests.functionality=!0}async storeAPK(e,t,i,s){const a=x("sha256").update(await c.readFile(t)).digest("hex"),r={id:`storage-${Date.now()}`,buildId:e,productId:i,version:s,apkPath:t,apkSize:(await c.stat(t)).size,checksum:a,downloadUrl:`/api/apk/download/${e}`,protected:!0,createdAt:new Date};return this.apkStorage.set(r.id,r),r.downloadUrl}startQueueProcessor(){setInterval(async()=>{await this.processQueue()},5e3)}async processQueue(){if(Array.from(this.activeBuilds.values()).filter(i=>i.status==="building"||i.status==="testing").length>=this.MAX_CONCURRENT_BUILDS)return;const t=this.buildQueue.find(i=>i.status==="queued");t&&(t.status="processing",t.startedAt=new Date,this.processBuild(t.buildId).catch(i=>{console.error(`Build ${t.buildId} failed:`,i),this.handleBuildFailure(t,i)}))}async processBuild(e){const t=this.activeBuilds.get(e);if(!t)return;try{t.status="building";const s=await this.getBuildSource(t.sourceId),a=await this.scanRepository(e,s);await this.autoFixProject(e,o.join(this.BUILD_DIR,e),a);const r=await this.buildAPK(e);await this.secureAPK(e,r),await this.integrateKeySystem(e,r);const n=await this.testAPK(e,r);if(t.testResults=n,n.status==="passed"){const l=await this.storeAPK(e,r,s.projectId,"1.0.0");t.downloadUrl=l,t.status="success"}else t.status="failed",t.errors.push("APK tests failed");t.endTime=new Date}catch(s){t.status="failed",t.errors.push(s.message),t.endTime=new Date}const i=this.buildQueue.find(s=>s.buildId===e);i&&(i.status=t.status==="success"?"completed":"failed",i.completedAt=new Date),this.buildHistory.push(t)}async handleBuildFailure(e,t){e.retryCount++,e.retryCount<e.maxRetries?(e.status="queued",this.addLog(e.buildId,"warn",`Retrying build (${e.retryCount}/${e.maxRetries})`,"queue")):(e.status="failed",this.addLog(e.buildId,"error",`Build failed permanently: ${t.message}`,"queue"))}async getBuildStatus(e){return this.activeBuilds.get(e)||null}async getBuildLogs(e){const t=this.activeBuilds.get(e);return t?t.logs:[]}async retryBuild(e){const t=this.activeBuilds.get(e);if(!t||t.status!=="failed")return!1;t.status="pending",t.errors=[],t.logs=[],t.startTime=new Date,t.endTime=void 0;const i={id:`queue-${Date.now()}`,buildId:e,priority:"high",status:"queued",queuedAt:new Date,retryCount:0,maxRetries:3};return this.buildQueue.push(i),!0}async downloadAPK(e){const t=this.activeBuilds.get(e);return!t||t.status!=="success"||!t.apkPath?null:t.apkPath}async fileExists(e){try{return await c.access(e),!0}catch{return!1}}async hasBuildConfig(e){const t=["webpack.config.js","vite.config.js","rollup.config.js","next.config.js"];for(const i of t)if(await this.fileExists(o.join(e,i)))return!0;return!1}async getDependencies(e){const t=o.join(e,"package.json");if(!await this.fileExists(t))return[];const i=JSON.parse(await c.readFile(t,"utf-8"));return Object.keys({...i.dependencies,...i.devDependencies})}addLog(e,t,i,s){const a=this.activeBuilds.get(e);a&&a.logs.push({timestamp:new Date,level:t,message:i,step:s})}async getBuildSource(e){return{id:e,type:"github",url:"https://github.com/example/repo",projectId:"project-1",adminId:"admin-1",timestamp:new Date}}getActiveBuilds(){return Array.from(this.activeBuilds.values())}getBuildQueue(){return[...this.buildQueue]}getStoredAPKs(){return Array.from(this.apkStorage.values())}getLicenseKeys(){return Array.from(this.licenseKeys.values())}getTestResults(){return Array.from(this.testResults.values())}async cleanup(){const e=Array.from(this.activeBuilds.entries()).filter(([t,i])=>Date.now()-i.startTime.getTime()>864e5);for(const[t,i]of e)try{const s=o.join(this.BUILD_DIR,t);await c.rm(s,{recursive:!0,force:!0}),this.activeBuilds.delete(t)}catch(s){console.error(`Failed to cleanup build ${t}:`,s)}}};u(h,"instance");let y=h;const k=y.getInstance();export{k as a};
