const a="/assets/saas-vala-logo-B2d0ly7D.jpg";export{a as s};
